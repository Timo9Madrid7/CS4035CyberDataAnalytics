```python
pip install -r requirements.txt
```

- numpy==1.19.2
- matplotlib==3.3.2
- seaborn==0.11.0
- matplotlib_venn==0.11.6
- imbalanced_learn==0.7.0
- jupyterthemes==0.20.0
- pandas==1.1.3
- imblearn==0.0
- ipython==7.23.0
- scikit_learn==0.24.2
