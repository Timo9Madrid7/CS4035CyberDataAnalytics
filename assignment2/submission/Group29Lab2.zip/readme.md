Lab2 instructions

The Group29-Lab2.ipynb contains all the algorithm and models we implement in lab2.

The whole time spent on running this .ipynb file is about 30 minutes.



The libraries required are listed in the requirements.txt file.

The training data set is SWaT_train.csv and the testing data set is SWaT_test.csv, which is downloaded from brightspace. 

The .zip contains:

arma folder: save the trained ARMA model data 

figures: save the results of models, which are used for comparison task

ngramdata: save the trained N-gram model data